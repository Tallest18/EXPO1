import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React from "react";
import { Text, TouchableOpacity, View } from "react-native";

import { homeStyles as styles, moderateScale } from "./homeStyles";

interface ActionButtonsProps {
  onAddProduct: () => void;
}

const ActionButtons: React.FC<ActionButtonsProps> = ({ onAddProduct }) => {
  const router = useRouter();

  return (
    <View style={styles.row}>
      <TouchableOpacity
        style={[styles.actionBox, { backgroundColor: "#061E47" }]}
        onPress={onAddProduct}
        activeOpacity={0.8}
      >
        <Text style={{ color: "#fff" }}>New Product </Text>
        <Ionicons
          name="add-circle-outline"
          size={moderateScale(30)}
          color="#fff"
        />
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.actionBox, { backgroundColor: "#1155CC" }]}
        onPress={() => router.push("/(Routes)/QuickSellScreen")}
        activeOpacity={0.8}
      >
        <Text style={{ color: "#fff" }}>Quick Sell </Text>
        <Ionicons
          name="add-circle-outline"
          size={moderateScale(30)}
          color="#fff"
        />
      </TouchableOpacity>
    </View>
  );
};

export default ActionButtons;
