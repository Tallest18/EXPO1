import React, { useState } from "react";
import { FlatList, SafeAreaView } from "react-native";

import AddProductFlow from "../(Routes)/AddProductFlow";
import ActionButtons from "@/components/home/ActionButtons";
import HomeHeader from "@/components/home/HomeHeader";
import NotificationFeed from "@/components/home/NotificationFeed";
import SalesSummary from "@/components/home/SalesSummary";
import StatCards from "@/components/home/StatCards";
import { homeStyles as styles, verticalScale } from "@/components/home/homeStyles";
import { useHomeData } from "@/hooks/useHomeData";

const Home = () => {
  const [showAddProduct, setShowAddProduct] = useState(false);
  const { inventory, notifications, userData, handleAddProduct } = useHomeData();

  const renderHeader = () => (
    <>
      <HomeHeader name={userData.name} profileImage={userData.profileImage} />
      <StatCards
        todaySales={userData.todaySales}
        profit={userData.profit}
        transactions={userData.transactions}
        stockLeft={userData.stockLeft}
      />
      <ActionButtons onAddProduct={() => setShowAddProduct(true)} />
      <SalesSummary salesSummary={userData.salesSummary} />
    </>
  );

  const renderFooter = () => (
    <NotificationFeed notifications={notifications} />
  );

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={[]}
        keyExtractor={() => "main-list"}
        renderItem={null}
        ListHeaderComponent={renderHeader}
        ListFooterComponent={renderFooter}
        contentContainerStyle={{ paddingBottom: verticalScale(40) }}
        showsVerticalScrollIndicator={false}
      />

      <AddProductFlow
        visible={showAddProduct}
        onClose={() => setShowAddProduct(false)}
        onSaveProduct={handleAddProduct}
      />
    </SafeAreaView>
  );
};

export default Home;
