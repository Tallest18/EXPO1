import { Feather, Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React from "react";
import { Image, Text, TouchableOpacity, View } from "react-native";

import { homeStyles as styles, moderateScale, scale } from "./homeStyles";

interface HomeHeaderProps {
  name: string;
  profileImage: string;
}

const HomeHeader: React.FC<HomeHeaderProps> = ({ name, profileImage }) => {
  const router = useRouter();

  return (
    <View style={styles.header}>
      <Text style={styles.hello}>Hello,</Text>
      <View
        style={{
          display: "flex",
          width: "100%",
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          gap: scale(12),
        }}
      >
        <Text style={styles.username} numberOfLines={1}>
          {" "}
          {name}
        </Text>
        <View style={styles.headerIcons}>
          <TouchableOpacity
            onPress={() => router.push("/(Routes)/NotificationsScreen")}
            activeOpacity={0.7}
          >
            <Ionicons
              name="notifications-outline"
              size={moderateScale(24)}
              color="black"
            />
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => router.push("/(Routes)/MessagesScreen")}
            activeOpacity={0.7}
          >
            <Feather name="message-square" size={moderateScale(24)} color="black" />
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => router.push("/(Routes)/Profile")}
            activeOpacity={0.7}
          >
            <Image
              source={
                profileImage
                  ? { uri: profileImage }
                  : require("../../assets/images/icon.png")
              }
              style={styles.avatar}
            />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export default HomeHeader;
