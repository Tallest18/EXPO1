import { Feather, Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React from "react";
import { FlatList, Text, TouchableOpacity, View } from "react-native";

import { homeStyles as styles, moderateScale, scale } from "./homeStyles";
import { Notification } from "./homeTypes";

interface NotificationFeedProps {
  notifications: Notification[];
}

const getNotificationIcon = (type: Notification["type"]) => {
  switch (type) {
    case "low_stock":
    case "out_of_stock":
      return <Feather name="package" size={moderateScale(24)} color="#1155CC" />;
    case "high_selling":
      return <Feather name="trending-up" size={moderateScale(24)} color="#1155CC" />;
    case "expiry":
      return <Feather name="calendar" size={moderateScale(24)} color="#1155CC" />;
    case "daily_summary":
    case "weekly_summary":
      return <Feather name="bar-chart-2" size={moderateScale(24)} color="#1155CC" />;
    default:
      return (
        <Ionicons
          name="notifications-outline"
          size={moderateScale(24)}
          color="#1155CC"
        />
      );
  }
};

const NotificationFeed: React.FC<NotificationFeedProps> = ({ notifications }) => {
  const router = useRouter();

  return (
    <View style={styles.notificationSection}>
      <View style={styles.notificationHeader}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: scale(8) }}>
          <Ionicons name="notifications" size={moderateScale(24)} color="#FACC15" />
          <Text style={styles.notificationHeaderTitle}>Notifications</Text>
        </View>
        <TouchableOpacity
          onPress={() => router.push("/(Routes)/NotificationsScreen")}
          activeOpacity={0.7}
        >
          <Text style={styles.viewAllLink}>View all notification</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={notifications.slice(0, 3)}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.notificationCard}
            onPress={() =>
              router.push({
                pathname: "/(Routes)/NotificationDetails" as any,
                params: { notification: JSON.stringify(item) },
              })
            }
            activeOpacity={0.7}
          >
            <View style={styles.notifLeftSection}>
              <View style={styles.notifIconBox}>
                {getNotificationIcon(item.type)}
              </View>
              <View style={styles.notifContent}>
                <View style={styles.notifTitleRow}>
                  <Text style={styles.notifTitle} numberOfLines={1}>
                    {item.title}
                  </Text>
                  <Text style={styles.notifTime}>{item.time}</Text>
                </View>
                <Text style={styles.notifMessage} numberOfLines={2}>
                  {item.message}
                </Text>
                {(item.type === "low_stock" || item.type === "out_of_stock") && (
                  <Text style={styles.notifActions} numberOfLines={1}>
                    Tap to restock | View product page
                  </Text>
                )}
                {item.type === "daily_summary" && (
                  <Text style={styles.notifActions}>
                    Tap to open Daily Sales Summary
                  </Text>
                )}
              </View>
            </View>
            {!item.isRead && <View style={styles.unreadDot} />}
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <Text style={styles.emptyText}>No recent updates</Text>
        }
        scrollEnabled={false}
      />
    </View>
  );
};

export default NotificationFeed;
